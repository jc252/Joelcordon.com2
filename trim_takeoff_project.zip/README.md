# Automated Trim Takeoff Project

This repository contains the code and LaTeX paper for a machine learning pipeline aimed at automating Division 6 trim takeoffs from architectural blueprints. The goal of this work is to reduce manual effort and improve consistency when quantifying finish carpentry materials such as baseboards, casings, and moldings.

## Overview

The project demonstrates how to parse PDF blueprints, preprocess raster images, train a YOLO-based detector to identify doors and trim proxies, calibrate blueprint scales, and convert detections into linear footage (LF) quantities. It also provides a LaTeX manuscript that documents the methodology, related work, results, and future directions.

## Repository Structure

```
trim_takeoff_project/
├── README.md          # Project summary and folder descriptions
├── main.tex            # LaTeX manuscript with full paper content
├── refs.bib            # BibTeX bibliography entries used in the manuscript
└── src/                # Python scripts for the data processing pipeline
    └── parse_pdfs.py   # Convert PDF pages into images using PyMuPDF
```

### main.tex

The `main.tex` file contains a full draft of the paper titled **"Automated Trim Takeoff from Architectural Blueprints: A Machine Learning Approach for Division 6 Estimating"**. It includes an abstract, introduction, background and related work, methodology, results, discussion, future work, and conclusion. Each section is properly structured and ready for editing. The LaTeX document uses `biblatex` for managing citations.

### refs.bib

The `refs.bib` file provides a complete BibTeX bibliography for sources referenced throughout the manuscript. When compiling the LaTeX document, `biber` should be run after `pdflatex` to generate the references.

### src/parse_pdfs.py

This Python script demonstrates how to convert PDF pages into PNG images using **PyMuPDF**. It accepts a PDF file path and an output directory, then iterates over each page and saves it as a high-resolution PNG. This preprocessing step prepares blueprint drawings for downstream computer vision tasks.

## Usage

1. Install the required Python dependencies:
   ```bash
   pip install PyMuPDF
   ```

2. Convert PDF sheets to images:
   ```bash
   python src/parse_pdfs.py --pdf path/to/blueprint.pdf --out path/to/output/images
   ```

3. Compile the LaTeX manuscript:
   ```bash
   pdflatex main.tex
   biber main
   pdflatex main.tex
   pdflatex main.tex
   ```

This repository serves as a foundation for further development. You are encouraged to expand the dataset, implement object detection and segmentation models, and refine the estimation logic described in the manuscript.