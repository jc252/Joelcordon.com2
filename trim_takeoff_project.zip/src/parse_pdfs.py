"""
parse_pdfs.py
================

This script provides a simple example of how to convert a multi-page PDF file
containing architectural blueprints into individual PNG images. The images can
then be processed by machine learning models for object detection and
segmentation tasks.

Usage
-----
Run the script from the command line by specifying the input PDF and the
output directory:

    python parse_pdfs.py --pdf path/to/blueprint.pdf --out path/to/output

The script uses PyMuPDF (installed as `fitz`) to load the PDF, iterate over
pages, and save each as a PNG. It uses a rendering scale factor of 2.0 to
produce high-resolution images; adjust this value based on your desired
resolution and memory constraints.
"""

import argparse
import pathlib
import fitz  # PyMuPDF


def export_pdf_pages(pdf_path: pathlib.Path, out_dir: pathlib.Path, scale: float = 2.0) -> None:
    """Export all pages of a PDF to PNG files.

    Parameters
    ----------
    pdf_path : pathlib.Path
        Path to the source PDF file.
    out_dir : pathlib.Path
        Directory where the images will be saved. Will be created if missing.
    scale : float, optional
        Rendering scale factor. A value of 2.0 corresponds roughly to
        144 DPI. Increase for higher resolution; decrease to save memory.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    doc = fitz.open(pdf_path)
    for i, page in enumerate(doc):
        # Increase resolution by scaling the matrix
        matrix = fitz.Matrix(scale, scale)
        pix = page.get_pixmap(matrix=matrix, alpha=False)
        out_path = out_dir / f"{pdf_path.stem}_page_{i+1:03d}.png"
        pix.save(out_path.as_posix())
        print(f"Saved {out_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Convert PDF pages to images.")
    parser.add_argument("--pdf", type=str, required=True, help="Path to the PDF file or directory of PDFs")
    parser.add_argument("--out", type=str, default="images", help="Output directory for images")
    parser.add_argument("--scale", type=float, default=2.0, help="Rendering scale (2.0 ≈ 144 DPI)")
    args = parser.parse_args()

    pdf_input = pathlib.Path(args.pdf)
    out_dir = pathlib.Path(args.out)

    if pdf_input.is_dir():
        for pdf in pdf_input.glob("*.pdf"):
            export_pdf_pages(pdf, out_dir, args.scale)
    else:
        export_pdf_pages(pdf_input, out_dir, args.scale)


if __name__ == "__main__":
    main()